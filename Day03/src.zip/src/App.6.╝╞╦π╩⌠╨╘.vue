<template>
  <div>
    <!-- 购物车 -->
    <table>
      <thead>
        <tr>
          <td><input type="checkbox" />全选</td>
          <td>图片</td>
          <td>名称</td>
          <td>价格</td>
          <td>数量</td>
          <td>小计</td>
        </tr>
      </thead>

      <tbody>
        <tr v-for="(p, i) in products" :key="i">
          <td><input type="checkbox" /></td>
          <td><img :src="p.img" alt="" /></td>
          <td>{{ p.name }}</td>
          <td>¥{{ p.price }}</td>
          <td>
            <!-- disabled 表单元素的属性, 不可用, 不能交互 -->
            <!-- true生效  false不生效 -->
            <button @click="p.count--" :disabled="p.count == 1">-</button>
            <span>{{ p.count }}</span>
            <button @click="p.count++">+</button>
          </td>
          <td>¥{{ p.price * p.count }}</td>
        </tr>
      </tbody>

      <tfoot>
        <tr>
          <!-- methods中的方法, 使用时需要() -->
          <td colspan="6" align="right">合计: {{ total() }}</td>
        </tr>

        <tr>
          <!-- computed中的方法, 使用时不需要() -->
          <td colspan="6" align="right">合计: {{ total2 }}</td>
        </tr>
      </tfoot>
    </table>
  </div>
</template>

<script>
export default {
  data() {
    return {
      // 名字,价格,数量,是否勾选,图片
      products: [
        {
          img: require('./assets/heros/Annie.jpg'),
          name: '哥特萝莉',
          price: 79,
          count: 1,
          checked: false,
        },
        {
          img: require('./assets/heros/Galio.jpg'),
          name: '幽蓝梦魇 加里奥',
          price: 100,
          count: 1,
          checked: false,
        },
        {
          img: require('./assets/heros/Gwen.jpg'),
          name: '咖啡甜心 格温',
          price: 110,
          count: 1,
          checked: false,
        },
        {
          img: require('./assets/heros/LeeSin.jpg'),
          name: '龙的传人 李青',
          price: 1200,
          count: 1,
          checked: false,
        },
      ],
    }
  },
  methods: {
    total() {
      // 遍历商品, 计算所有商品价格的总和
      var sum = 0
      // forEach: 在JS高级 数组高阶函数中讲解的
      this.products.forEach(p => (sum += p.price * p.count))
      return sum
    },
  },
  // 配置项:computed 称为计算属性
  // 作用: 存放在这里的函数, 使用时不用(), 会自动触发. 适合没有参数的函数
  computed: {
    total2() {
      var sum = 0
      this.products.forEach(p => (sum += p.price * p.count))
      return sum
    },
  },
}
</script>

<style lang="scss" scoped>
table {
  // 边框合并
  border-collapse: collapse;

  thead {
    background-color: #eee;
  }

  td {
    border: 1px solid gray;
    padding: 5px 15px;

    img {
      width: 100px;
    }
  }
}
</style>
