<template>
  <div>
    <div>
      <label>
        <!-- 双向绑定特点: 当DOM元素的值变化时, 能自动更新给变量 -->
        {{ agree }}
        <input type="checkbox" v-model="agree" />
        <span>我已阅读并同意用户注册协议</span>
      </label>
    </div>
    <!-- disabled: 不可用 -->
    <button :disabled="!agree">注册账号</button>
  </div>
</template>

<script>
export default {
  data() {
    return {
      agree: false, //同意: 假
    }
  },
}
</script>

<style lang="scss" scoped></style>
