<template>
  <div>
    <!-- 范式 v-for="值 in/of 数组" -->
    <!-- 波浪线: 不是一个实际的错误, 而是 vscode插件觉得你错误 -->
    <!-- 因为 插件推荐你书写一个 key 属性, 存放唯一标识 (不能重复) -->

    <!-- key是什么? 做标记的 -- 当数组发生变化后的重用问题 -->

    <!-- key在数组内容发生修改的时候, 可以提高性能, 直接复用元素 -->
    <!-- 但是 key 仅仅在数组有变化的时候 才有用 -->
    <!-- 数组如果没有变更, 则key没有任何作用 -->

    <!-- 如果值重复, 则不能做唯一标识: 实在没办法用序号 -->
    <!-- 理论上, 数据来自服务器, 服务器的数据必然带有 主键id -->
    <!-- <button v-for="emp in emps" :key="emp">{{ emp }}</button> -->
    <button v-for="(emp, i) in emps" :key="i">{{ i }},{{ emp }}</button>

    <button v-for="(emp, i) in emps">{{ emp }}</button>

    <!-- key有什么用? 为元素添加唯一标识, 方便复用 -->

    <!-- 
      当参加学校举办的运动会, 每个人都喝矿泉水.  需要班级去走方阵... 当走完以后, 回来的时候, 怎么知道哪瓶水 是谁喝的
      -- 解决方案: 做标记即可, 必须是唯一的
     -->
  </div>
</template>

<script>
export default {
  data() {
    return {
      emps: ['壮壮', '浩浩', '文青', '贝贝', '冬冬', '浩浩'],
    }
  },
}
</script>

<style lang="scss" scoped></style>
