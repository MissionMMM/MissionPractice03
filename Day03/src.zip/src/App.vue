<template>
  <div>
    <!-- 多选 -->
    <h3>壮壮同学, 请勾选你熟练的技能, 便于本公司挑选人才</h3>
    <p>您勾选的技能: {{ skills }}</p>
    <div>
      <div>
        <input type="checkbox" value="0" v-model="skills" />
        <span>HTML5</span>
      </div>
      <div>
        <input type="checkbox" value="1" v-model="skills" />
        <span>CSS</span>
      </div>
      <div>
        <input type="checkbox" value="2" v-model="skills" />
        <span>JavaScript</span>
      </div>
      <div>
        <input type="checkbox" value="3" v-model="skills" />
        <span>Vue</span>
      </div>
    </div>
  </div>
</template>

<script>
export default {
  data() {
    return {
      // v-model属于一个很智能的属性
      // v-model="变量"
      // 如果变量类型是 boolean, 认为 判断是否勾选, true/false
      // 如果变量类型是 array, 认为 是多选操作, 把值添加到数组里
      skills: [], //多选操作, 使用数组来存储选项
    }
  },
}
</script>

<style lang="scss" scoped></style>
