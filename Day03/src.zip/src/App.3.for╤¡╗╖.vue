<template>
  <div>
    <!-- vue 的for循环, 能够直接遍历数字 -->
    <div class="pages">
      <!-- 遍历的起始值是 1 -->
      <!-- 高亮: nowPage 和 元素自带的p 相同, 就高亮 -->

      <!-- key: 是给vue系统看的, 我们不能主动使用 -->
      <span
        v-for="p in 10"
        :key="p"
        @click="nowPage = p"
        :data-p="p"
        :class="{ active: nowPage == p }"
      >
        {{ p }}
      </span>
    </div>

    <h3>当前页: {{ nowPage }}</h3>
  </div>
</template>

<script>
export default {
  data() {
    return {
      nowPage: 1, // 当前页=1
    }
  },
}
</script>

<style lang="scss" scoped>
.pages {
  background-color: #f5f5f6;
  user-select: none;
  padding: 20px;
  display: flex;

  span {
    width: 40px;
    line-height: 40px;
    text-align: center;
    background-color: white;
    margin-right: 10px;
    border-radius: 5px;
    color: #4e6ef2;

    &.active {
      background-color: #4e6ef2;
      color: white;
    }
  }
}
</style>
