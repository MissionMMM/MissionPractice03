<template>
  <div>
    <!-- assets: 专门放资源 -- 图片 -->
    <img
      :class="{ active: now == 0 }"
      @click="now = 0"
      src="./assets/heros/Annie.png"
      alt=""
    />
    <img
      :class="{ active: now == 1 }"
      @click="now = 1"
      src="./assets/heros/Galio.png"
      alt=""
    />
    <img
      :class="{ active: now == 2 }"
      @click="now = 2"
      src="./assets/heros/Gwen.png"
      alt=""
    />
    <img
      :class="{ active: now == 3 }"
      @click="now = 3"
      src="./assets/heros/LeeSin.png"
      alt=""
    />
    <img
      :class="{ active: now == 4 }"
      @click="now = 4"
      src="./assets/heros/Zoe.png"
      alt=""
    />

    <hr />
    <!-- i 是序号, 下标 -->
    <img
      v-for="(img, i) of imgs"
      :src="img"
      alt=""
      :key="i"
      :data-i="i"
      @click="now = i"
      :class="{ active: now == i }"
    />

    <h2>now:{{ now }}</h2>
  </div>
</template>

<script>
export default {
  data() {
    return {
      now: 0, //当前序号
      // 用数组存储所有的图片地址, 然后用循环方式生成
      imgs: [
        // 图片在JS中使用, 必须用 require 方法引入, 否则无法加载
        // 具体原因与脚手架的webpack工具机制有关, 后期铭铭老师讲解
        require('./assets/heros/Annie.png'),
        require('./assets/heros/Galio.png'),
        require('./assets/heros/Zoe.png'),
        require('./assets/heros/Seraphine.png'),
        require('./assets/heros/LeeSin.png'),
      ],
    }
  },
}
</script>

<style lang="scss" scoped>
img.active {
  border-radius: 50%;
}
</style>
