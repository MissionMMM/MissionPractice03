<template>
  <div>
    <!-- 凡是页面上会变化的东西, 必然和数据有关 -->
    <div class="box">
      <div>
        <!-- 动态样式  :class="{类名: true/false}" -->
        <span :class="{ active: item == 'zh' }" @click="item = 'zh'">
          账号登录</span
        >
        <span :class="{ active: item == 'dx' }" @click="item = 'dx'"
          >短信登录</span
        >
      </div>
      <div>
        <!-- ==: 比较, 值一样就行, 类型不一样会自动转一样 -->
        <!-- ===: 比较 值 和 类型都一样 -->
        <div v-show="item == 'zh'">
          <input type="text" placeholder="手机号/用户名/邮箱" />
          <input type="password" placeholder="密码" />
        </div>
        <div v-show="item == 'dx'">
          <input type="text" placeholder="请输入手机号" />
          <input type="text" placeholder="验证码" />
        </div>
      </div>
    </div>
  </div>
</template>

<script>
export default {
  data() {
    return {
      item: 'zh',
    }
  },
}
</script>

<style lang="scss" scoped>
// 如果书写 scss 语法有报错, 说明你生成项目时 没有加载css预编译工具
.box {
  width: 300px;
  background-color: #eee;

  > div:first-child {
    padding: 10px;
    user-select: none;

    span {
      margin-right: 16px;
      color: #666;
      padding-bottom: 4px;
      // & 并且;  相当于 span.active
      &.active {
        color: #000;
        border-bottom: 2px solid blue;
      }
    }
  }
}
</style>
