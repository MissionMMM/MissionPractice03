<template>
  <div>
    <div class="box">
      <!-- 解析: 通过激活的序号, 从imgs数组中得到对应的栏目, 读取其中的大图 -->
      <img :src="imgs[now].lg" alt="" />
      <div>
        <!-- 任务: 通过遍历, 把小图 sm 都展示出来 -->
        <img
          v-for="(img, i) in imgs"
          :key="i"
          :src="img.sm"
          alt=""
          @mouseover="now = i"
          :class="{ active: now == i }"
        />
      </div>
    </div>
  </div>
</template>

<script>
export default {
  data() {
    return {
      // 大小图切换: 1个大图 对应 1个小图
      imgs: [
        // small:小  large:大
        {
          sm: require('./assets/heros/Annie.png'),
          lg: require('./assets/heros/Annie.jpg'),
        },
        {
          sm: require('./assets/heros/Galio.png'),
          lg: require('./assets/heros/Galio.jpg'),
        },
        {
          sm: require('./assets/heros/Zoe.png'),
          lg: require('./assets/heros/Zoe.jpg'),
        },
        {
          sm: require('./assets/heros/Gwen.png'),
          lg: require('./assets/heros/Gwen.jpg'),
        },
      ],
      now: 0, //当前激活序号
    }
  },
}
</script>

<style lang="scss" scoped>
.box > div > img {
  transition: 0.3s;

  &.active {
    border-radius: 20px;
  }
}
</style>
