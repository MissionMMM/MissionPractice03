<template>
  <div>
    <!-- v-model 指令:  称为 双向数据绑定 -->
    <!-- v-model属于一个智能属性, 会自动判断所在的元素类型, 然后为对应的属性绑定值 -->

    <!-- 方向1: 数据gx 绑定给了 勾选框的checked 属性 -->
    <!-- 方向2: 操作元素的时候, 会自动更新相关的数据 -->
    <input type="checkbox" v-model="gx" />
    <p>当前勾选状态: {{ gx }}</p>

    <!-- 简单说: v-model的作用, 收集用户操作的信息, 例如 勾选框, 单选框, 下拉选框, 输入框... -->
  </div>
</template>

<script>
export default {
  data() {
    return {
      gx: true, //勾选: 初始true
    }
  },
}
</script>

<style lang="scss" scoped></style>
