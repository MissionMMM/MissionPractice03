<template>
  <div>
    <!-- 表单元素: 可以收集用户信息的元素 -- 输入框,单选,多选,勾选, 下拉选框 -->

    <!-- v-model: 特点就是 实时更新数据; 所以uname变量中存储的一定是输入框最新的值 -->
    <input type="text" v-model="uname" placeholder="请输入姓名" />
    <div>uname:{{ uname }}</div>
    <br />
    <button @click="showHello">问好</button>
  </div>
</template>

<script>
export default {
  data() {
    return {
      uname: '',
    }
  },
  methods: {
    showHello() {
      alert('欢迎' + this.uname + '光临本店')
    },
  },
}
</script>

<style lang="scss" scoped></style>
